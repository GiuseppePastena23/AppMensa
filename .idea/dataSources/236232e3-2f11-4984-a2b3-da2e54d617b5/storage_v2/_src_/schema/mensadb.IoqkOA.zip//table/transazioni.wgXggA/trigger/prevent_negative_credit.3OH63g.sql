create definer = android@`%` trigger prevent_negative_credit
    before insert
    on transazioni
    for each row
BEGIN
    DECLARE nuovo_credito FLOAT;

    -- Calcola il nuovo credito dopo la transazione
    SELECT credito + NEW.importo INTO nuovo_credito
    FROM users
    WHERE id = NEW.user_id;

    -- Se il nuovo credito sarebbe negativo, lancia un errore
    IF nuovo_credito < 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Transazione fallita: credito insufficiente';
    END IF;
END;

