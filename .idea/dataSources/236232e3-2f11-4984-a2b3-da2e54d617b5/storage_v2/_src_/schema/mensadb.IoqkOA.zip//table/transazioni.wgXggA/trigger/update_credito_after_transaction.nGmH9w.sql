create definer = android@`%` trigger update_credito_after_transaction
    after insert
    on transazioni
    for each row
BEGIN
    -- Aggiorna il credito dell'utente basato sull'importo della transazione
    UPDATE users
    SET credito = credito + NEW.importo
    WHERE id = NEW.user_id;
END;

